from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import pandas as pd

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load your trained model
with open('C:\\Users\\NEHA KL\\Desktop\\manipal\\xgb_model.pkl', 'rb') as file:
    model = pickle.load(file)

# Load column names
with open('C:\\Users\\NEHA KL\\Desktop\\manipal\\columns.pkl', 'rb') as file:
    columns = pickle.load(file)

@app.route('/')
def welcome():
    return 'Welcome to the Demand Forecasting API!'

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        print(f"Received data: {data}")

        # Create DataFrame with reduced columns
        input_data = {
            'SKU': [data.get('SKU')],
            'Qty': [int(data.get('Qty'))],
            'Year': [int(data.get('Year'))],
            'Month': [int(data.get('Month'))]
        }
        df = pd.DataFrame(input_data)
        print(f"Input DataFrame: {df}")

        # Ensure the DataFrame has all necessary columns in the correct order
        df = df.reindex(columns=columns, fill_value=0)
        print(f"Reindexed DataFrame: {df}")

        # Convert SKU to categorical
        df['SKU'] = df['SKU'].astype('category')
        print(f"DataFrame with categorical SKU: {df}")

        # Make prediction
        prediction = model.predict(df)
        prediction_value = float(prediction[0])  # Convert to standard Python float
        print(f"Prediction value: {prediction_value}")
        return jsonify({'prediction': prediction_value})
    except Exception as e:
        import traceback
        print(f"Error: {traceback.format_exc()}")
        return jsonify({
            'error': str(e),
            'message': 'Error processing the request',
            'trace': traceback.format_exc()
        })

if __name__ == '__main__':
    app.run(debug=True)
