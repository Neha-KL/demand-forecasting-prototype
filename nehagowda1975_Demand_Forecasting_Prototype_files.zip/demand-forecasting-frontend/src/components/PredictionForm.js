import React, { useState } from 'react';
import axios from 'axios';
import '../App.css';  // Import the CSS file

const PredictionForm = () => {
    const [formData, setFormData] = useState({
        SKU: '',
        Qty: '',
        Year: '',
        Month: ''
    });
    const [prediction, setPrediction] = useState(null);
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setPrediction(null);
        try {
            const response = await axios.post('http://127.0.0.1:5000/predict', formData);
            console.log('API Response:', response.data);
            setPrediction(response.data.prediction);
        } catch (err) {
            console.error('API Error:', err);
            setError(err.response ? err.response.data : 'Error making prediction');
        }
    };

    return (
        <div className="container">
            <h1>AI Powered Demand Forecasting System</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    SKU:
                    <input type="text" name="SKU" value={formData.SKU} onChange={handleChange} required />
                </label>
                <label>
                    Qty:
                    <input type="number" name="Qty" value={formData.Qty} onChange={handleChange} required />
                </label>
                <label>
                    Year:
                    <input type="number" name="Year" value={formData.Year} onChange={handleChange} required />
                </label>
                <label>
                    Month:
                    <input type="number" name="Month" value={formData.Month} onChange={handleChange} required />
                </label>
                <button type="submit">Predict</button>
            </form>
            {prediction !== null && <p>Prediction: {prediction}</p>}
            {error && (
                <pre>
                    Error: {JSON.stringify(error, null, 2)}
                </pre>
            )}
        </div>
    );
};

export default PredictionForm;
