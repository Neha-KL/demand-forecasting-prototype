import React from 'react';
import PredictionForm from './components/PredictionForm';
import './App.css';  // Import the CSS file

function App() {
    return (
        <div className="App">
            <PredictionForm />
        </div>
    );
}

export default App;
